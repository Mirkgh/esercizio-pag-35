/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package esercitazione;

/**
 *
 * @author ospite
 */
public class Esercitazione {

    
    public static void main(String[] args) {
        dimensioni al = new dimensioni();
      
        
        al.set_dimensioni(6);
        for (int i= 0; i<6; i++) {
            for(int j=0; j<6; j++) {
           String asterisco = "*";
           System.out.println(asterisco);
            }
            
            
        }
        }
    }
    

